NEWSX — starter PWA
===================

This is the first working prototype of NEWSX, designed as an installable web app.

FILES
- index.html: app structure
- styles.css: responsive dark premium design
- app.js: category switching, search, refresh, RSS loading
- manifest.webmanifest: install metadata
- sw.js: basic offline shell cache

RUN LOCALLY
For service workers, use a local web server (not file://).
If Python is installed:
  python3 -m http.server 8000
Then open:
  http://localhost:8000

PUBLISH FREE (starter approach)
1. Create a GitHub account/repository and upload these files.
2. Enable GitHub Pages for the repository.
3. Open the published HTTPS URL on your phone.
4. iPhone: Safari > Share > Add to Home Screen.
   Android: Chrome menu > Install app / Add to Home Screen.

NEWS FEED NOTE
The prototype reads Google News RSS feeds through the public AllOrigins CORS proxy.
Both the feed provider and proxy are third-party services. They can change, rate-limit,
or stop working; this is not guaranteed unlimited or production-grade. For a reliable
public launch, we should add a small server-side RSS aggregator and review publisher
terms, attribution, caching, and source coverage.

CURRENT MVP
- India, World, Business, Technology, Sports, Entertainment
- Search headlines and source names
- Refresh button
- Opens the original publisher/article link
- Responsive phone layout and basic PWA shell

NEXT BUILD STEPS
1. Add proper app icons and splash assets.
2. Add Hindi/English language selector.
3. Add source selection and saved stories.
4. Add breaking-news notifications (requires a push backend and user permission).
5. Improve feed reliability and add more reputable RSS sources.
