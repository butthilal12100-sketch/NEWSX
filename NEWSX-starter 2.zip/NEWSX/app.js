const FEEDS = {
  India: "https://news.google.com/rss/search?q=India&hl=en-IN&gl=IN&ceid=IN:en",
  World: "https://news.google.com/rss/headlines/section/topic/WORLD?hl=en-IN&gl=IN&ceid=IN:en",
  Business: "https://news.google.com/rss/headlines/section/topic/BUSINESS?hl=en-IN&gl=IN&ceid=IN:en",
  Technology: "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?hl=en-IN&gl=IN&ceid=IN:en",
  Sports: "https://news.google.com/rss/headlines/section/topic/SPORTS?hl=en-IN&gl=IN&ceid=IN:en",
  Entertainment: "https://news.google.com/rss/headlines/section/topic/ENTERTAINMENT?hl=en-IN&gl=IN&ceid=IN:en"
};

const grid = document.getElementById("newsGrid");
const statusEl = document.getElementById("status");
const titleEl = document.getElementById("sectionTitle");
const searchEl = document.getElementById("searchInput");
let category = "India";
let stories = [];
let deferredInstall = null;

function cleanText(value) {
  const doc = new DOMParser().parseFromString(value || "", "text/html");
  return (doc.body.textContent || "").trim();
}
function timeAgo(dateString) {
  const date = new Date(dateString);
  if (Number.isNaN(date.getTime())) return "Latest";
  const mins = Math.max(0, Math.floor((Date.now() - date.getTime()) / 60000));
  if (mins < 60) return `${mins} min ago`;
  if (mins < 1440) return `${Math.floor(mins / 60)} hr ago`;
  return `${Math.floor(mins / 1440)} days ago`;
}
function render() {
  const term = searchEl.value.trim().toLowerCase();
  const filtered = stories.filter(s => s.title.toLowerCase().includes(term) || s.source.toLowerCase().includes(term));
  grid.innerHTML = "";
  if (!filtered.length) {
    grid.innerHTML = `<div class="empty">No matching headlines. Try another search or refresh.</div>`;
    return;
  }
  for (const story of filtered) {
    const article = document.createElement("article");
    article.className = "news-card";
    const meta = document.createElement("div");
    meta.className = "card-meta";
    const source = document.createElement("span");
    source.className = "source";
    source.textContent = story.source;
    const time = document.createElement("span");
    time.textContent = timeAgo(story.date);
    meta.append(source, time);
    const heading = document.createElement("h3");
    heading.textContent = story.title;
    const link = document.createElement("a");
    link.className = "read-link";
    link.href = story.link;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = "READ FULL STORY ↗";
    article.append(meta, heading, link);
    grid.append(article);
  }
}
async function loadNews() {
  statusEl.textContent = "Fetching the latest headlines…";
  grid.innerHTML = "";
  const feedUrl = FEEDS[category];
  try {
    // Public CORS proxy used for this free prototype. It may be rate-limited or unavailable.
    const proxy = "https://api.allorigins.win/raw?url=" + encodeURIComponent(feedUrl);
    const response = await fetch(proxy, { cache: "no-store" });
    if (!response.ok) throw new Error("Feed request failed");
    const xmlText = await response.text();
    const xml = new DOMParser().parseFromString(xmlText, "text/xml");
    if (xml.querySelector("parsererror")) throw new Error("Could not read feed");
    stories = [...xml.querySelectorAll("item")].slice(0, 30).map(item => {
      const link = item.querySelector("link")?.textContent?.trim() || "#";
      const rawTitle = item.querySelector("title")?.textContent || "Untitled story";
      const title = cleanText(rawTitle);
      let source = "NEWS SOURCE";
      try { source = new URL(link).hostname.replace(/^www\./, "").split(".")[0].toUpperCase(); } catch {}
      return { title, link, source, date: item.querySelector("pubDate")?.textContent || "" };
    }).filter(s => s.title && s.link !== "#");
    statusEl.textContent = `${stories.length} headlines · ${category} · Updated just now`;
    render();
  } catch (error) {
    stories = [];
    statusEl.textContent = "News feed is temporarily unavailable. Check your connection and try again.";
    render();
  }
}

document.getElementById("categories").addEventListener("click", event => {
  const button = event.target.closest("button[data-category]");
  if (!button) return;
  document.querySelectorAll(".chip").forEach(chip => chip.classList.toggle("active", chip === button));
  category = button.dataset.category;
  titleEl.textContent = category === "India" ? "Top stories" : category;
  loadNews();
});
document.getElementById("refreshBtn").addEventListener("click", loadNews);
searchEl.addEventListener("input", render);

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstall = event;
  document.getElementById("installBtn").classList.remove("hidden");
});
document.getElementById("installBtn").addEventListener("click", async () => {
  if (!deferredInstall) return;
  deferredInstall.prompt();
  await deferredInstall.userChoice;
  deferredInstall = null;
  document.getElementById("installBtn").classList.add("hidden");
});
if ("serviceWorker" in navigator) window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));

loadNews();
